# Kanban Board

**Version:** 1.0.0  

Desktop application for task management using Kanban methodology.

## Quick Start:

1. Go to `Build/` folder
2. Run `build.bat`
3. EXE will be created in `App/` folder
4. Run `App/KanbanBoard.exe`

## Or run without building:

```bash
python Source/kanban_app.py
```

## Structure:

- **App/** - Ready application (after build)
- **Source/** - Source code
- **Build/** - Build scripts

## Features:

- Three Kanban columns: To Do, In Progress, Done
- Dark Mode (moon/sun button)
- Auto-save data to JSON
- Task tags: bug, feature, fix, design
- Move tasks with arrow buttons
- Delete tasks with X button

## Requirements:

- Python 3.8+
- tkinter (included in Python)
- PyInstaller (for building EXE)

## Technologies:

- Python + tkinter
- PyInstaller
- JSON
