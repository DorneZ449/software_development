Run this in App/ folder after building
